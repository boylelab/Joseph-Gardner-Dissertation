'''
Created on Jul 8, 2016

@author: joey
'''

# DEPRECATED CLASS
import cobra
import cobra.test
import os
from os.path import join
import makeTery as mT

#Accepts a working directory for Cobra ready .xml files and a dictionary for both species: source and species: objectives
def initPy(sourceDictionary, objDictionary, workingDirectory = None):
    modDict = {}
    for key in sourceDictionary.keys():
        modDict[key] = {}
        fN = sourceDictionary[key]
        if type(sourceDictionary[key]) is str: model = cobra.io.read_sbml_model(join(workingDirectory,fN))
        else: model = sourceDictionary[key]
        if key in objDictionary: objective = objDictionary[key]
        else: objective = ['EX_biomass']
        modDict[key]['model'] = model
        modDict[key]['objective'] = objective
    return modDict

# Trichodesmium initializer
def initTricho(fileName, workingDirectory, species):
    cLdz = {'DZ':['EX_cyanophycin','EX_biomass']}
    cLpa = {'PA':['EX_glycogen','EX_biomass']}
    model = cobra.io.read_sbml_model(join(workingDirectory, fileName))
    [modeldz,modelpa] = mT.makeTery(model)
    if species == 'DZ':
        sourceDict = {'DZ': modeldz}
        objDict = cLdz
    else:
        sourceDict = {'PA': modelpa}
        objDict = cLpa
    modDict = initPy(sourceDict, objDict)
    return modDict
