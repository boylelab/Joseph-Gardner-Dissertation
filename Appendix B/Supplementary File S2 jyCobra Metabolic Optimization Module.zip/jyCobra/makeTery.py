'''
Created on Jul 7, 2016

@author: joey
'''
from cobra import Model, Reaction, Metabolite
from cobra import *
import cobra.test
import os
from os.path import join
import copy

# Sets cell specific constraints for two cell types
def makeTery(model):
    try:
        exgly = Reaction('EX_glycogen')
        model.add_reaction(exgly)
        exgly.name = 'Glycogen Export'
        exgly.subsystem = 'Export'
        exgly.lower_bound = 0
        exgly.upper_bound = 1000
        exgly.objective_coefficent = 0
    
        trgly = Reaction('TR_glycogen')
        model.add_reaction(trgly)
        trgly.name = 'Glycogen Transport'
        trgly.subsystem = 'Transport'
        trgly.lower_bound = -1000
        trgly.upper_bound = 1000
        trgly.objective_coefficient = 0
    
        trcph = Reaction('TR_cyanophycin')
        model.add_reaction(trcph)
        trcph.name = 'Cyanophycin Transport'
        trcph.subsystem = 'Transport'
        trcph.lower_bound = -1000
        trcph.upper_bound = 1000
        trcph.objective_coefficient = 0
    
        excph = Reaction('EX_cyanophycin')        
        model.add_reaction(excph)
        excph.name = 'Cyanophycin Exchange'
        excph.subsystem = 'Exchange'
        excph.lower_bound = -1000
        excph.upper_bound = 1000
        excph.objective_coefficient = 0
    
        m_glycogen_e = Metabolite('m_glycogen_e',name='Glycogen[e]',compartment = 'e')
        m_glycogen_c = Metabolite('m_glycogen_c',name='Glycogen[c]',compartment = 'c')
    
        m_cph_e = Metabolite('m_cyanophycin_e',name='cyanophycin[e]',compartment='e')
        m_cph_c = model.metabolites.get_by_id('m_asp_arg_c')
    
        exgly.add_metabolites({m_glycogen_e: -1})
        trgly.add_metabolites({m_glycogen_c: -1, m_glycogen_e: 1})
    
        excph.add_metabolites({m_cph_e: -1})
        trcph.add_metabolites({m_cph_c:-1, m_cph_e: 1})
    except:
        pass
    
    # Remove bad cycles
    model.reactions.get_by_id('ASP_ASPASE').upper_bound = 1000
    model.reactions.get_by_id('ASP_ASPASE').lower_bound = 0
    model.reactions.get_by_id('VAL_avtA').lower_bound = 0
    model.reactions.get_by_id('GLY_G3PDH').lower_bound = 0
    model.reactions.get_by_id('NUC_ndk_AG').lower_bound = 0
    model.reactions.get_by_id('TR_orthopi').lower_bound = 0
    
    # Remove exogenouse carbon/nitrogen sources
    model.reactions.get_by_id('EX_no2').upper_bound = 0
    model.reactions.get_by_id('EX_no2').lower_bound = 0
    
    # Set energy sources
    model.reactions.get_by_id('EX_photon').lower_bound = -100
    model.reactions.get_by_id('EX_photon').upper_bound = -100
    model.reactions.get_by_id('EX_proton').upper_bound = 0
    model.reactions.get_by_id('EX_proton').lower_bound = 0
    model.reactions.get_by_id('EX_biomass').upper_bound = 1000
    model.reactions.get_by_id('EX_biomass').lower_bound = 0
    model.reactions.get_by_id('EN_ATP').lower_bound = 0
    model.reactions.get_by_id('EN_ATP').upper_bound = 1000
    
    # Set overall objective
    model.reactions.get_by_id('EX_biomass').objective_coefficient = 1
    
    # Photoautotroph
    modelpa = model.copy()
    modelpa.reactions.get_by_id('EX_o2').upper_bound = 1000
    modelpa.reactions.get_by_id('EX_o2').lower_bound = 0
    modelpa.reactions.get_by_id('EX_co2').lower_bound = -1000
    modelpa.reactions.get_by_id('EX_co2').upper_bound = 0
    modelpa.reactions.get_by_id('EX_n2').lower_bound = 0
    modelpa.reactions.get_by_id('EX_n2').upper_bound = 1000
    modelpa.reactions.get_by_id('EX_glycogen').upper_bound = 1000
    modelpa.reactions.get_by_id('EX_glycogen').lower_bound = 0
    modelpa.reactions.get_by_id('EX_nh4').upper_bound = 0
    modelpa.reactions.get_by_id('EX_nh4').lower_bound = 0
    modelpa.reactions.get_by_id('EX_no3').lower_bound = 0
    modelpa.reactions.get_by_id('EX_cyanophycin').upper_bound = 0
    modelpa.reactions.get_by_id('EX_cyanophycin').lower_bound = -1000
    modelpa.reactions.get_by_id("EX_urea").upper_bound = 0
    
    # Diazotroph
    modeldz = model.copy()
    modeldz.reactions.get_by_id('EN_ATP').lower_bound = 0
    modeldz.reactions.get_by_id('EX_o2').upper_bound = 1000
    modeldz.reactions.get_by_id('EX_o2').lower_bound = -1000
    modeldz.reactions.get_by_id('EX_no3').upper_bound = 1000
    modeldz.reactions.get_by_id('EX_no3').lower_bound = 0
    modeldz.reactions.get_by_id('EX_nh4').upper_bound = 1000
    modeldz.reactions.get_by_id('EX_nh4').lower_bound = 0
    modeldz.reactions.get_by_id('TR_nh4').upper_bound = 1000
    modeldz.reactions.get_by_id('TR_nh4').lower_bound = -1000
    modeldz.reactions.get_by_id('EX_co2').lower_bound = 0
    modeldz.reactions.get_by_id('EX_co2').upper_bound = 1000
    modeldz.reactions.get_by_id('Photo_II').upper_bound = 0
    modeldz.reactions.get_by_id('Photo_II').lower_bound = 0
    modeldz.reactions.get_by_id('EX_n2').lower_bound = -1000
    modeldz.reactions.get_by_id('EX_n2').upper_bound = 0
    modeldz.reactions.get_by_id('EX_glycogen').lower_bound = -1000
    modeldz.reactions.get_by_id('EX_cyanophycin').upper_bound = 1000
    modeldz.reactions.get_by_id('EX_cyanophycin').lower_bound = 0
    modeldz.reactions.get_by_id('EX_h2o').upper_bound = 1000
    
    # Set in situ Constraints
    modelpa.reactions.get_by_id('EX_co2').upper_bound = 0
    modeldz.reactions.get_by_id('EX_cyanophycin').objective_coefficient = 1
    modeldz.reactions.get_by_id('EX_glycogen').objective_coefficient = 0
    
    modelpa.reactions.get_by_id('EX_biomass').upper_bound = 1000
    modeldz.reactions.get_by_id('EX_biomass').upper_bound = 1000

    return [modeldz, modelpa]
