import re
from cobra import *
import sys
from collections import defaultdict
import numpy as np
import math
import itertools
import matplotlib.pyplot as plt

class fbaPareto(object):
    # Accepts cellName (also indicates type), model, inConstraints: boolean of whether
    # there are internal constraints in the model (can't be simplified to EX_Rxns only)
    # CellLib is a list of objective functions linked to cell type names. This is defined
    # at the SuperClass for all cells
    
    # Call this class' functions to:
    # -Update model
    # -Redraw Pareto Front
    # -Select points
    # -Make decisions for point selections
    # -Draw the graph (visualize changing solution space)
    
    # Initialize Class
    def __init__(self, \
                 cellName, \
                 model, \
                 inConstraints, \
                 cellLib, \
                 max = True \
                 ):
        
        # Assign data to variables
        self.cellName = cellName
        self.model = model.copy()
        self.inConstraints = inConstraints
        self.cellLib = cellLib
        self.max = max
        self.obj = cellLib[self.cellName]
        
        # Binary Pareto Front, multi Pareto Front under development
        if len(self.obj) >= 2:
            self.obj1 = self.obj[0]
            self.obj2 = self.obj[1]
        else:
            print("Not enough objectives.")
            self.obj1 = self.model.reactions(0).id
            self.obj2 = self.model.reactions(1).id
    # Find all exchange reactions; this can be used to simplify solution space. If
    # 13C-MFA, etc., are used, will have to iterate through every reaction for constraints.
        self.EX_rxns = []
        if inConstraints:
            self.EX_rxns = self.model.reactions
        else:
            r = re.compile('EX_.*')
            for rxn in self.model.reactions:
                if r.match(str(rxn.id)) is not None:
                    self.EX_rxns.append(rxn)
    
    # Update constraints for an existing Pareto front (which should previously exist for
    # every instance of a cell class, separately
    # rxnID is a string by which to look up rxn
    # dataDict is structures as {'rxnID': [lb, ub, obj]}
    def updateConstraints(self, dataDict):
        for rxnID in dataDict.keys():
            if dataDict[rxnID]['isObj'] is False:
                try:
                    self.model.reactions.get_by_id(rxnID).lower_bound = dataDict[rxnID]['lb']
                    self.model.reactions.get_by_id(rxnID).upper_bound = dataDict[rxnID]['ub']
                except KeyError:
                    print("No reaction in database")
        
    # Determine lines between each set of optimal points. OptPoints now has constraint: (x1*,y1*),(x2*,y2*),m,b
    def drawLines(self):
        self.findOpts()
        for c in self.optPoints.keys():
            x1 = self.optPoints[c][0][0]
            x2 = self.optPoints[c][1][0]
            y1 = self.optPoints[c][0][1]
            y2 = self.optPoints[c][1][1]
            if x1 == x2:
                self.optPoints[c].append(float("inf"))
            else:
                self.optPoints[c].append((y2-y1)/(x2-x1))
                self.optPoints[c].append(y1 - (y2-y1)*x1/(x2-x1))
        
    # Using the drawLines values, determine the intersections of each graph.
    # Store pertinent intersections in their own list: rotate clockwise from lowest (constrained solution)
    # to next closest point (down for min, up for max, default max) along lines to describe polygon.
    # Deprecated method
    def findIntersections(self):
        self.drawLines()
        d = 1000
        pt = [100,100]
        constraint = ""
        ints = []
        self.paretoArray = []
        if self.max:
            # Find lowest right point
            for c in self.optPoints.keys():
                x1 = self.optPoints[c][0][0]
                x2 = self.optPoints[c][1][0]
                y1 = self.optPoints[c][0][1]
                y2 = self.optPoints[c][1][1]
                if x1 != x2 and y1 != y2:
                    dtemp1 = ((x1**2 + y1**2)**(0.5))
                    dtemp2 = ((x2**2 + y2**2)**(0.5))
                    if dtemp1 < dtemp2: 
                        dtemp = dtemp1
                        ptTemp = [x1,y1]
                    else: 
                        dtemp = dtemp2
                        ptTemp = [x2,y2]
                    if dtemp < d:
                        d = dtemp
                        pt = ptTemp
                        constraint = c
                self.paretoArray.append(pt)
            # Find all intersections
            for con in self.optPoints.keys():
                for co in self.optPoints.keys():
                    if co != constraint:
                        if len(self.optPoints[con]) >= 4 and len(self.optPoints[co]) >= 4:
                            m = self.optPoints[con][2]
                            n = self.optPoints[co][2]
                            b = self.optPoints[con][3]
                            c = self.optPoints[co][3]
                            if n != m:
                                xint = (b-c)/(n-m)
                                yint = m*xint + b
                                if xint > pt[0] and yint > 0:   ints.append([xint, yint])
            # Rotate through points
            if len(ints) == 0:
                bT = 1000
                for cons in self.optPoints.keys():
                    if self.optPoints[cons][3] < bT: 
                        bT = self.optPoints[cons][3]
                        pt1 = self.optPoints[cons][0]
                        pt2 = self.optPoints[cons][1]
                        self.paretoArray = [pt1,pt2]
            while len(ints) > 1:
                intsTemp = ints
                ints = []
                dist = 1000
                # Find closest picture
                for i in intsTemp:
                    distTemp = (((i[0] - pt[0])**2 + (i[1] - pt[1])**2)**(0.5))
                    if distTemp < dist:
                        dist = distTemp
                        pt = i
                # Remove infeasible points
                for p in intsTemp:
                    if p[0] > pt[0]:
                        ints.append(p)
                self.paretoArray.append(pt)
            if not self.paretoArray:
                self.paretoArray = ([0,0],[optPoints[obj1][0],optPoints[obj2][1]])
            self.arrangePareto()
    
    def arrangePareto(self):
        xs = []
        ys = []
        for p in self.paretoArray:
            xs.append(p[0])
            ys.append(p[1])
        self.pareto = {self.obj1: xs, self.obj2: ys}
            
                        
    # Find optimal points (for each constraint, Ci) after finding optima for !C
    # 1. x1,i* = Max{Obj1} s.t. Ci
    # 2. Set Obj1 = x*
    # 3. Max{Obj2} s.t. Obj1 = x1,i*, Ci
    # 4. Store pair of points as (x1,i*,y1,i*)
    # 5. y2,i* = Max{Obj2} s.t. Ci
    # 6. Set Obj2 = y2,i*
    # 7. Max{Obj1} s.t. Obj2 = y2,i*, Ci
    # 8. Store second set of points as (x2,i*, y2,i*). This describes one line, where Ci is restrictive.
    # 9. Next constraint, Ci+1
    def findOpts(self):
        obj1 = self.obj1
        obj2 = self.obj2
        firstPass = True
        # Find all constraints (nonzero, nonthousand)
        self.findConstraints()
        # Empty array
        optPoints = []
        self.constraints.append("NO CONSTRAINT")
        # Iterate through all constraints, only one of which is active at any time
        for c in self.constraints:
            # Interim model so as not to disrupt stored model
            modelC = self.model.copy()
            modelC = self.zeroObjectives(modelC)
            # Set all other objectives to unconstrained (if zero, this means irreversible, don't set)
            for co in self.constraints:
                if c != co and co != "NO CONSTRAINT":
                    modelC.reactions.get_by_id(co).upper_bound = 1000.0
                    modelC.reactions.get_by_id(co).lower_bound = -1000.0
            # Find x1*
            modelC.reactions.get_by_id(obj1).objective_coefficient = 1
            modelC.optimize()
            x1 = modelC.solution.f
            # Find y2*
            modelC.reactions.get_by_id(obj2).objective_coefficient = 1
            modelC.reactions.get_by_id(obj1).objective_coefficient = 0
            modelC.optimize()
            y2 = modelC.solution.f
            # Find y1*
            modelC2 = modelC.copy()
            modelC2.reactions.get_by_id(obj1).upper_bound = x1
            modelC2.reactions.get_by_id(obj1).lower_bound = x1
            modelC2.optimize()
            y1 = modelC2.solution.f
            # Find x2*
            modelC.reactions.get_by_id(obj2).upper_bound = y2
            modelC.reactions.get_by_id(obj2).lower_bound = y2
            modelC.reactions.get_by_id(obj1).objective_coefficient = 1
            modelC.reactions.get_by_id(obj2).objective_coefficient = 0
            modelC.optimize()
            x2 = modelC2.solution.f
            # Remove Nones
            if x1 is None: x1 = 0
            if x2 is None: x2 = 0
            if y1 is None: y1 = 0
            if y2 is None: y2 = 0
            # Store solutions
            if firstPass:
                optPoints = {c:[[x1,y1],[x2,y2]]}
                firstPass = False
            else:
                optPoints[c] = [[x1,y1],[x2,y2]]
        self.optPoints = optPoints
                
    # Iterate through reactions (exchange reactions if no internal restrictions) for reactions where
    # zeroes and thousands are gone.
    def findConstraints(self):
        self.constraints = []
        for rxn in self.EX_rxns:
            if ((self.model.reactions.get_by_id(rxn.id).lower_bound != -1000.0 and self.model.reactions.get_by_id(rxn.id).lower_bound != 0.0)
                or (self.model.reactions.get_by_id(rxn.id).upper_bound != 0.0 and self.model.reactions.get_by_id(rxn.id).upper_bound != 1000.0)):
                    self.constraints.append(rxn.id)
    
    # Iterate through every reaction and set it to no objective
    def zeroObjectives(self, model):
        for r in model.reactions:
            model.reactions.get_by_id(r.id).objective_coefficient = 0
        return model
    
    # Generate all weight combinations and create a Pareto Front
    def pSearch(self):
        
        # Prepare model
        modelP = self.model.copy()
        modelP = self.zeroObjectives(modelP)
        for rxn in modelP.reactions:
            if rxn.lower_bound > rxn.upper_bound:
                print(rxn.id + ": [" + str(rxn.lower_bound) + ", " + str(rxn.upper_bound) + "]")
        modelP.optimize()
        modelP = self.zeroObjectives(modelP)
        perms = []
        
        # Generate all objective weight permutations
        for v in get_perms_to_one(0.01, len(self.obj)):
            perms.append(v)
        finalPerms = list(perms for perms, _ in itertools.groupby(perms))
        perms = finalPerms
        weighted = {}
        for o in self.obj:
            modelP.reactions.get_by_id(o).lower_bound = 0
            modelP.reactions.get_by_id(o).upper_bound = 0
        
        self.pareto = {}
        for o in self.obj:
            self.pareto[o] = []
        self.pareto['sol'] = []
        self.allWeights = {}
        j=0
        
        # Iterate through permutations to generate possible Pareto Fronts
        for p in perms:
            for i in range(0, len(self.obj)):
                weighted[self.obj[i]] = p[i]
            modelC = self.setObjEqn(weighted, modelP)
            
            modelC.optimize()
            
            sol = modelC.solution.f
            if sol is None:
                sol = 0
            self.allWeights[sol] = p
            for ob in self.obj:
                self.pareto[ob].append(sol*weighted[ob])
            self.pareto['sol'].append(sol)
    
    # Add objective equation to the model
    def setObjEqn(self, weights, model):
        model_one_obj = model.copy()
        if self.hasObj(model):
            model.reactions.get_by_id('r_objective').delete()
        rxn = Reaction('r_objective')
        rxn.name = 'Multi objective scalarized reaction.'
        rxn.subsystem = 'Objective'
        rxn.lower_bound = -1000.
        rxn.upper_bound = 1000.
        rxn.objective_coefficient = 1.
        for rxnName in weights.keys():
            reaction = model_one_obj.reactions.get_by_id(rxnName)
            weight = weights[rxnName]
            for met in reaction.metabolites:
                coef = reaction.get_coefficient(met.id)
                rxn.add_metabolites({met: coef*weight})
        model_one_obj.add_reaction(rxn)
        model_one_obj.change_objective(rxn.id)
        return model_one_obj

    # Check to see if it has an objective function
    def hasObj(self, model):
        if 'r_objective' in model.reactions._dict:
            return True
        return False
    
    # Visualize the permutation graph 
    def pSearchGraph(self):
        solx = self.pareto[self.obj1]
        soly = self.pareto[self.obj2]
        plt.plot(solx, soly, 'b-')
        plt.ylabel(self.obj2)
        plt.xlabel(self.obj1)
        plt(self.ave)
        plt.show()
    
# Get all permutations of n objectives that add up to 1
def get_perms_to_one(meshSize, num_objs, numbers=[], partial=[], partial_sum=0):
    if numbers == []:
        numbers = list(np.arange(0,1+meshSize/2.,meshSize))
        for i in range(1,num_objs,1):
            numbers.append(0)
        nums = numbers
        for i in range(1,num_objs,1):
            nums = nums + numbers
        numbers = nums
    if partial_sum > 1 or len(partial) > num_objs:
        return
    if partial_sum == 1 and len(partial) == num_objs:
        yield partial
    for i, n in enumerate(numbers):
        remaining = numbers[i+1:]
        yield from get_perms_to_one(meshSize, num_objs, remaining, partial + [n], partial_sum + n)   
        
        