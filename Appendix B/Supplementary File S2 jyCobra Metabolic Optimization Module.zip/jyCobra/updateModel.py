# Note: this requires that external concentrations be converted to fluxes. Fluxes can be estimated via Michaelis-Menten kinetics
# or experimentally. Java will do this computation. Python only works with the most basic information: models and fluxes.
# Has structure dictionary = {str Reaction ID: [lb, ub]}

def updateModel(model, externalFluxes):
    if type(externalFluxes) is dict:
        for key in externalFluxes.keys():
            try:
                if type(externalFluxes[key]) is list:
                    if type(externalFluxes[key][0]) is list:
                        lb = sum(externalFluxes[key][0])/len(externalFluxes[key][0])
                        ub = sum(externalFluxes[key][1])/len(externalFluxes[key][1])
                    else:
                        lb = externalFluxes[key][0]
                        ub = externalFluxes[key][1]
                    model.reactions.get_by_id(key).lower_bound = lb
                    model.reactions.get_by_id(key).upper_bound = ub
                elif type(externalFluxes[key]) is int or type(externalFluxes[key]) is float:
                    b = externalFluxes[key]
                    model.reactions.get_by_id(key).lower_bound = b
                    model.reactions.get_by_id(key).upper_bound = b
            except KeyError:
                print("No reaction available with the name: "+ key)
                break
    else:
        print("Invalid data for fluxes: must be dictionary of form {Reaction ID: [lb,ub]} or {Rxn ID: bb}")
    return model