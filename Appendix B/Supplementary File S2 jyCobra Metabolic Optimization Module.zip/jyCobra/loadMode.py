'''
Created on Jul 8, 2016

@author: joey
'''
# Initializes the Pareto Front methods and the TERY model (DEPRECATED)
import cobra
import cobra.test
import os
from os.path import join
import drawPareto as dP
import makeTery as mT
def loadModel(fN):
    dd = cobra.test.data_directory
    cNdz = 'DZ'
    cNpa = 'PA'
    cLdz = {'DZ':['EX_cyanophycin','EX_biomass']}
    cLpa = {'PA':['EX_glycogen','EX_biomass']}
    model = cobra.io.read_sbml_model(join(dd,fN))
    [modeldz,modelpa] = mT.makeTery(model)
    fPdz = dP.fbaPareto(cNdz,modeldz,True,cLdz)
    fPpa = dP.fbaPareto(cNpa,modelpa,True,cLpa)
    return[fPdz,fPpa]