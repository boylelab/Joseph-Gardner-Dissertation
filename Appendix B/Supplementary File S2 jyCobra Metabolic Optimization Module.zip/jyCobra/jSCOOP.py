import cobra
from cobra import Model,Metabolite,Reaction
from cobra.flux_analysis import parsimonious

import initPy as iP
import updateModel as uM
import runCobraPy as r

import os
import json
import math
import re
import time
import collections
import copy
from six import iteritems

import csv

import pandas

from pebble import ProcessPool
import multiprocessing
from multiprocessing import cpu_count
from concurrent.futures import TimeoutError

class jScoop():
    
    # Initializes the class
    # fluxes are in terms of specific metabolites, dictionary of {metabolite: flux}
    def __init__(self, \
                 model, \
                 fluxes, \
                 tic, \
                 species, \
                 eqn, \
                 condition = "", \
                 name="", \
                 required_export = "", \
                 names = None, \
                 weights = None, \
                 catModel = None \
                 ):
        
        # Assign to class variables
        self.model = model
        self.weights = weights
        
        # Round weights to reduce computation time by allowing progression to primary production in lieu of strict metabolism
        if type(self.weights) is list:
            for i in range(0, len(self.weights)):
                for k in self.weights[i]:
                    if self.weights[i][k] > 0.999:
                        self.weights[i][k] = 1
                    elif self.weights[i][k] < 0.001:
                        self.weights[i][k] = 0
        
        
        self.condition = condition
        self.fluxes = fluxes
        self.tic = tic
        self.species = species
        self.export = required_export
        self.names = names
        self.name = name
        
        # Dictionary of cells satisfying catabolic, metabolic, or stationary productions
        self.catabolic = {}
        self.anabolic = {}
        self.stationary = {}
        
        # Generate catabolic (backflow) model if one isn't given
        if not catModel:
            try:
                self.catModel = self.getCatModel()
            except ValueError:
                self.catModel = ''
        else:
            self.catModel = catModel
            
        # Load equation and fluxes from metabolites
        if type(eqn) is str:
            self.eqn = json.loads(eqn)
        elif type(eqn) is dict:
            self.eqn = eqn
        if type(self.fluxes) is dict:
            self.exchanges = self.chooseRxns(self.fluxes)
        else:
            self.exchanges = fluxes
            
        # Generate null dict that says cell is dead
        self.nullDict = {}
        for rxn in self.model.reactions:
            self.nullDict[rxn.id] = 0
        
    # Startup from SBML, generates scalar equation through Pareto Matching algorithm
    @classmethod
    def init(cls, \
             dataFile, \
             species, \
             modelSBML, \
             condition, \
             name, \
             correctiveRxn, \
             tic, \
             fluxes = '', \
             required_export = "", \
             weights=None \
             ):
        
        # Load experimental data and model
        rCP = r.runCobraPy(dataFile, species, modelSBML, condition)
        
        # Load weights if user specified
        if weights is not None and type(weights) is str: weights = json.loads(weights)
        
        # Create scalar objective equation
        rCP.setupModel(species, condition, correctiveRxn, weights)
        
        # Retrieve model
        model = rCP.scalarModelDict[species][condition]
        
        # Retrieve equation
        eqn = copy.copy(r.runCobraPy.modDict[species]['bioDataObj'].weightObj)
        
        # Delete overhead
        del(rCP)
        
        # Load fluxes if given
        if fluxes is not '':
            fluxes = json.loads(fluxes)
        return cls(model, fluxes, tic, species, eqn, condition, name, required_export)

    # Startup from JSON if there's a legacy model set or for routine calculations    
    @classmethod    
    def initFromJSON(cls, \
                     jsonModFluxArray, \
                     tic, \
                     species, \
                     condition, \
                     name, \
                     required_export = "", \
                     weights=None \
                     ):
        
        # Load strings
        if type(jsonModFluxArray) is str: jsonModFluxArray = json.loads(jsonModFluxArray)
        
        # Parse list for appropriate data structures and load from JSON if they're strings
        fluxes = jsonModFluxArray[1]
        eqn = jsonModFluxArray[2]
        if type(fluxes) is str: fluxes = json.loads(fluxes)
        names = None
        catModel = None
        model = jsonToModel(jsonModFluxArray[0])
        if len(jsonModFluxArray) > 4:
            catModel = jsonToModel(jsonModFluxArray[4])
            
        # Pass weights controls whether these are plastic weights and should be handled as cells are optimized
        passWeights = None
        
        # Otherwise, set the global weights to be static
        if weights is not None:
            if type(weights) is str: weights = json.loads(weights)
            if type(weights) is dict: 
                model = setObjEqn(weights, model)
            else: passWeights = weights
        
        # Load all names
        if len(jsonModFluxArray) >= 4:
            names = json.loads(jsonModFluxArray[3])
        return cls(model, fluxes, tic, species, eqn, condition, name, required_export, names, passWeights, catModel)
    
    ## returns a json serialized list of [model (for data persistence), fluxes (dictionary/HashMap), obj reaction (dictionary/HashMap)]

    # Handles all optimization calls, either diverting through a single call or a parallelish one
    def runCobra(self, verbose=False):
        
        # For startup or singular cell optimizations:
        if type(self.fluxes) is str or type(self.fluxes) is dict:
            
            # Update model
            if self.fluxes is not '':
                self.model = uM.updateModel(self.model, self.exchanges)
                
            # Update model corrective reaction based on light
            self.model.reactions.get_by_id('EN_ATP').lower_bound = self.getATPM(abs(self.model.reactions.get_by_id('EX_photon').lower_bound))
            self.model.optimize(solver='cglpk')
            
            # If model can be optimized for metabolism:
            if self.model.solution and self.model.solution.f and self.model.solution.f > 1e-6:
                # Infer fluxes from objective reaction
                self.objRxnToFluxes(self.model)
                # Write results to file
                if self.names: self.writeToFile()
                # Interpret metabolite fluxes from model's exchange reactions
                exc = self.getExchange(self.model)
                self.fluxes = exc
            # Otherwise, progress to stationary/primary production
            else:
                # Shut off the objective equation
                self.model.reactions.get_by_id('r_objective').upper_bound = 0
                self.model.reactions.get_by_id('r_objective').lower_bound = 0
                
                # Tell the model to create the appropriate metabolite
                self.model.reactions.get_by_id(self.export).upper_bound = 1000
                self.model.objective = self.export
                self.model.optimize(solver='cglpk')
                
                # If this works, interpret fluxes and write to file
                if self.model.solution and self.model.solution.f and self.model.solution.f > 1e-6:
                    if self.names: self.writeToFile()
                    exc = self.getExchange(self.model)
                    self.fluxes = exc
                # Otherwise, catabolize its own biomass
                else: 
                    self.model.reactions.get_by_id('EX_biomass').lower_bound = -1*self.exchanges['EX_biomass'][1]
                    self.model.optimize(solver='cglpk')
                    if not self.model.solution.f or self.model.solution.f <= 1e-6:
                        flux = {}
                        allFluxes = {}
                    else:
                        exc = self.getExchange(self.model)
                        flux = exc
            return [self.modelToJSON(self.model), self.fluxes, self.eqn, self.modelToJSON(self.catModel)]
        
        # Handles several calls (fluxes are a list of dicts)
        elif type(self.fluxes) is list:
            # Run these constraints in parallel
            listsOfFluxes = self.runParallel(self.fluxes, self.weights, self.names, verbose)
            justFluxes = []
            fluxDicts = []
            names = []
            
            # Assign return to correct variables
            for arr in listsOfFluxes:
                justFluxes.append(arr[0])
                fluxDicts.append(arr[1])
                names.append(arr[3])
                self.anabolic.update(arr[4]['anabolic'])
                self.catabolic.update(arr[4]['catabolic'])
                self.stationary.update(arr[4]['stationary'])
            return [self.modelToJSON(self.model), justFluxes, self.eqn, names]

    # Prepares the model to run the cells in parallelish form
    def runParallel(self, \
                    fluxes, \
                    weightList, \
                    names, \
                    verbose=False \
                    ):
        listOfFluxes = []
        
        # Determine's machine's parallel capabilities
        cpus = cpu_count()
        cs = len(fluxes)/cpus
        
        # Timeout of program
        timeout = 20000
        fluxWeight = []
        
        # Iterate through fluxes and create the correct list format (since pool.map only supports a single argument)
        i = 0
        for f in fluxes:
            if weightList is None:
              fluxWeight.append([f, [], names[i], verbose])
            else:
              fluxWeight.append([f, weightList[i], names[i], verbose])
            i += 1
        
        # Run parallel set
        with ProcessPool() as pool:
            future = pool.map(self.runCobraParallel, fluxWeight, chunksize=2, timeout=timeout)
            try:
                for l in future.result():
                    listOfFluxes.append(l)
            except TimeoutError:
                print("Timing out")
                for l in fluxes:
                    listOfFluxes.append({},{},self.model, -1)
        return listOfFluxes

    # Run COBRA optimization on a single cell (this is the function called in parallel)    
    def runCobraParallel(self, fluxWeight):
        
        # Determine consumption and production reactions
        eatRxn = 'EX_cyanophycin'
        makeRxn = 'EX_glycogen'
        if self.export == 'EX_cyanophycin' or self.export == 'TR_n2':
            eatRxn = 'EX_glycogen'
            makeRxn = 'EX_cyanophycin'
            
        # Assign correct values
        model = self.model.copy()
        flux = fluxWeight[0]
        weight = fluxWeight[1]
        name = fluxWeight[2]
        verbose=fluxWeight[3]
        models = {'anabolic': {}, 'stationary': {}, 'catabolic': {}}
        
        # Update objective equation if the weight is specified
        if weight != [] and weight is not None: model = setObjEqn(weight, model)
        
        # Convert metabolite fluxes to the correct exchanges
        exchanges = self.chooseRxns(flux)
        
        # Update model constraints
        if flux is not '':
            model = uM.updateModel(model, exchanges)
            
        # Update model's ATP maintenance reaction based on the light intensity
        model.reactions.get_by_id('EN_ATP').lower_bound = self.getATPM(abs(model.reactions.get_by_id('EX_photon').lower_bound))
        
        # Don't let the model innately eat its own product
        makeLB = model.reactions.get_by_id(makeRxn).lower_bound
        if makeLB < 0:
            model.reactions.get_by_id(makeRxn).lower_bound = 0
            
##### ANABOLIZE #####
        model.reactions.get_by_id("EX_biomass").lower_bound = 0
        model.objective="r_objective"
        ppFlag = False # Tells the model to run primary production
        r = model.reactions.get_by_id('r_objective')
        
        # Convert to primary production if the values are really close to zero (to reduce computation time)
        for met in r.metabolites:
            if 'biomass' in met.id and abs(r.metabolites[met]) < 0.005:
                ppFlag = True
                break
        # Optimize
        model.optimize(solver='cglpk')
        
        # If this works, return the set of fluxes and model and objective equation, and add the model to the anabolic set
        if not ppFlag and model.solution and model.solution.f and model.solution.f > 1e-6:
            preModel = model.copy()
            if(verbose):
                models['anabolic'][str(name)] = model.copy()
            model.reactions.get_by_id('r_objective').lower_bound = model.solution.f
            model.reactions.get_by_id('r_objective').upper_bound = model.solution.f
            model.objective = makeRxn
            model.optimize()
            if model.solution.status == 'infeasible':
                 model = preModel.copy()
            self.objRxnToFluxes(model, weight)
            allFluxes = model.solution.x_dict
            exc = self.getExchange(model)
            flux = exc

    ##### PRIMARY PRODUCTION #####
        else:
            # Update model 
            preS = model.copy()
            if(verbose):
                # Debugging if the model seems weird. Prints out every intermediate solution
                print("Verbose")
                print(name)
                k = model.copy()
                for r in model.reactions:
                    for rx in k.reactions:
                        if rx.id.startswith("EX"):
                            rx.upper_bound = 1000
                    if r.id.startswith("EX") and r.id != "EX_photon" and \
                            r.id != "EX_proton" and r.id != self.export and \
                            r.id != "EX_biomass":
                        l = model.copy()
                        j = k.copy()
                        l.reactions.get_by_id(r.id).lower_bound = -1000
                        l.reactions.get_by_id(r.id).upper_bound = 1000
                        j.reactions.get_by_id(r.id).lower_bound = -1000
                        l.optimize(solver='cglpk')
                        if l.solution.f:
                            print(l.solution.f)
                            models['anabolic'][str(name) + "_" + r.id + "_lim"] = l.copy()
                            print("Export limited model: " + r.id)
                            print(l.solution.f)
                            for rxn in l.solution.x_dict:
                                if rxn.startswith("EX") and l.solution.x_dict[rxn] != 0:
                                    print(rxn + ": " + str(l.solution.x_dict[rxn]))
                        j.optimize(solver='cglpk')
                        print(j.solution.f)
                        if j.solution.f:
                            print(j.solution.f)
                            models['anabolic'][str(name) + "_" + r.id + "_unl"] = j.copy()
                            print("Export unlimited model: " + r.id)
                            print(j.solution.f)
                            for rxn in j.solution.x_dict:
                                if rxn.startswith("EX") and j.solution.x_dict[rxn] != 0:
                                    print(rxn + ": " + str(j.solution.x_dict[rxn]))
            # Close off the objective equation                    
            model.reactions.get_by_id('r_objective').upper_bound = 0
            model.reactions.get_by_id('r_objective').lower_bound = 0
            
            # Allow the model to create biomass and export the correct metabolite
            model.reactions.get_by_id('EX_biomass').upper_bound = 1000
            model.reactions.get_by_id(self.export).upper_bound = 1000
            
            # Don't let it eat the consumable (presumably because it's limiting)
            model.reactions.get_by_id(eatRxn).lower_bound = 0
            
            # Set the objective to primary production
            model.objective = self.export
            sol = parsimonious.optimize_minimal_flux(model)
            
            # Allow side exports to take place that also represent reduced carbon if this is a diazotroph
            if (self.export == 'EX_cyanophycin' or self.export == 'TR_n2') and (not sol or not sol.f or sol.f <= 1e-6):
                model.reactions.get_by_id('EX_nh4').upper_bound = 1000
                model.objective = 'EX_nh4'
                sol = parsimonious.optimize_minimal_flux(model)
                
            # If this is working, interpret fluxes and return
            if sol and sol.f:
                if(verbose):
                    # Prints the changes from this model to the original optimization (from the Pareto Matching, without new constraints)
                    print(sol.f)
                    model.optimize(solver='cglpk')
                    print(j.solution.f)
                    print("Gly diff: " + str(model.solution.x_dict['EX_glycogen'] - sol.x_dict['EX_glycogen']))
                    print("Cy diff: " + str(model.solution.x_dict['EX_cyanophycin'] - sol.x_dict['EX_cyanophycin']))
                    models['stationary']['preS_' + str(name)] = preS
                    models['stationary'][str(name)] = model.copy()
                allFluxes = model.solution.x_dict
                exc = self.getExchange(model)
                flux = exc
                
        ##### CATABOLISM #####
            else:
                # Finally, progress through a backflow-from-biomass equation
                preC = model.copy()
                if(verbose):
                    # Iterates through stationary results to see what was limiting and print every intermediate result for debugging
                    print("Stationary Results")
                    model.reactions.get_by_id("EX_biomass").upper_bound = 0
                    print(name)
                    k = model.copy()
                    for r in model.reactions:
                        for rx in k.reactions:
                            if rx.id.startswith("EX"):
                                rx.upper_bound = 1000
                        if r.id.startswith("EX") and r.id != "EX_photon" and \
                                r.id != "EX_proton" and r.id != self.export and \
                                r.id != "EX_biomass":
                            l = model.copy()
                            j = k.copy()
                            l.reactions.get_by_id(r.id).lower_bound = -1000
                            l.reactions.get_by_id(r.id).upper_bound = 1000
                            j.reactions.get_by_id(r.id).lower_bound = -1000
                            l.optimize(solver='cglpk')
                            if l.solution.f:
                                print(l.solution.f)
                                models['stationary'][str(name) + "_" + r.id + "_lim"] = l.copy()
                                print("Export limited model: " + r.id)
                                print(l.solution.f)
                                for rxn in l.solution.x_dict:
                                    if rxn.startswith("EX") and l.solution.x_dict[rxn] != 0:
                                        print(rxn + ": " + str(l.solution.x_dict[rxn]))
                            j.optimize(solver='cglpk')
                            if j.solution.f:
                                print(j.solution.f)
                                models['stationary'][str(name) + "_" + r.id + "_unl"] = j.copy()
                                print("Export unlimited model: " + r.id)
                                print(j.solution.f)
                                for rxn in j.solution.x_dict:
                                    if rxn.startswith("EX") and j.solution.x_dict[rxn] != 0:
                                        print(rxn + ": " + str(j.solution.x_dict[rxn]))
                
                # Optimize
                self.model.optimize(solver='cglpk')
                model = self.catModel.copy()
                if flux is not '':
                    model = uM.updateModel(model, exchanges)
                # Update reactions that are wonky and required to be a certain way
                model.reactions.get_by_id('EN_ATP').lower_bound = self.getATPM(abs(model.reactions.get_by_id('EX_photon').lower_bound))
                model.reactions.get_by_id("EX_co").lower_bound = -1
                model.reactions.get_by_id("EX_fe2").lower_bound = -0.01
                
                # Update maximal uptakes                
                model.reactions.get_by_id(makeRxn).lower_bound = makeLB
                
                # Minimize the catabolism
                model.objective = self.export
                
                # Reverse uptake reactions
                for rxn in model.reactions:
                    if rxn.id.startswith("EX"):
                        rxn.upper_bound = 1000
                model.reactions.get_by_id("EX_biomass").upper_bound = 0
                
                # If it works, return, otherwise return a nulldict that tells the cell to die
                model.optimize(solver='cglpk')
                if model.solution.status != 'infeasible' and model.solution.x_dict["EX_biomass"] < 0:
                    model.reactions.get_by_id(self.export).lower_bound = model.solution.f
                    model.objective = "EX_biomass"
                    model.optimize(solver='cglpk')
                if model.solution.status == 'infeasible':
                    flux = {}
                    allFluxes = {}
                else:
                    if(verbose):
                        models['catabolic']['preC_' + str(name)] = preC
                        print("Adding model")
                        models['catabolic'][str(name)] = model.copy()
                    exc = self.getExchange(model)
                    flux = exc
                    allFluxes = model.solution.x_dict
                    
        # Write to file
        if allFluxes == {}:
            self.writeToFile('', self.nullDict, name)
        else:
            self.writeToFile('', allFluxes, name)
        return [flux, allFluxes, model, name, models]

    # Writes the flux dict to file, either appending it as a new time point or starting a new one with a reactions column        
    def writeToFile(self, model='', fluxDict='', cellName=''):
        if cellName=='': cellName = 0
        dir = os.getcwd()
        dir1 = dir + "/fluxMaps/" + self.name
        if not os.path.exists(dir1):
            os.makedirs(dir1)
        if(model == '' and fluxDict == ''): 
            fluxDict = self.model.solution.x_dict
        elif fluxDict == '':
            fluxDict = model.solution.x_dict
        filePrefix = dir1 + "/fluxMap_"+self.species+'_'
        file = filePrefix + str(cellName) + ".csv"
        
        # Does the actual writing, determines if there's a previous file
        try: self.writeList(fluxDict, file)
        except(ValueError): pass

    # Handles writing to file    
    def writeList(self, fluxDict, file):
        if type(fluxDict) != dict:
            print("Type of fluxes isn't dict, it's " + type(fluxDict))
            return
        ordFluxDict = collections.OrderedDict(sorted(fluxDict.items()))
        
        # Starts new file
        if self.tic == -1.0:
            label = ['Reactions']
            
        # Tries to open a previous version
        else:
            label = str(self.tic)
        if(os.path.isfile(file)):
            df = pandas.read_csv(file)
            df[label] = ordFluxDict.values()
        else:
            df = pandas.DataFrame()
            df['Reactions'] = ordFluxDict.keys()
            try:
                df[label] = ordFluxDict.values()
            except(ValueError):
                pass
        
        # Writes
        with open(file, 'w') as f:
            df.to_csv(f,index=False)

    # Receive reactions from metabolite fluxes    
    def chooseRxns(self, fluxes):
        excDict = {}
        for met in fluxes.keys():
            if 'EX_' + met in self.model.reactions._dict:
                excDict['EX_' + met] = fluxes[met]
        return excDict
    
    # Calculates the ATP maintenance flux at different light intensities
    def getATPM(self, light):
        m = 0.987
        b = -16.6972
        #A = 94.4612
        #k = 6.055139e-3
        #c = -91.0712
        #Q = 49.3459
        #k = 1.4834e-2
        if self.species == 'PA':
            #A = 8.61378
            #k = 1.93133e-2
            #c = -6.11378
            m = 0.952
            b = -41.88992
            #Q = 178.695
            #k = 2.3088e-2
        light = abs(light)
        atp = m*light + b
        #atp = m*light + b
        if atp < 0:
            return 0
        else:
            return atp
    
    # Generates the catabolism model through backflow
    def getCatModel(self):
        model = self.model.copy()
        # Goes through to find solutions and reverses/turns off reactions that are for metabolism
        sol = parsimonious.optimize_minimal_flux(model)
        model.reactions.get_by_id("EX_photon").lower_bound = 0
        model.reactions.get_by_id("EX_photon").upper_bound = 0
        model.reactions.get_by_id("r_objective").lower_bound = 0
        model.reactions.get_by_id("r_objective").upper_bound = 0
        model.reactions.get_by_id(self.export).lower_bound = 0
        model.reactions.get_by_id(self.export).upper_bound = 1000
        model.reactions.get_by_id('EX_biomass').lower_bound = -1
        model.reactions.get_by_id('EX_biomass').upper_bound = -1
        model.reactions.get_by_id("EX_photon").lower_bound = 0
        model.reactions.get_by_id("EX_photon").upper_bound = 0
        uptakeRxn = ''
        
        # Cell type specific reaction types
        if self.export == 'EX_glycogen':
            uptakeRxn = "EX_co2"
            eatRxn = "EX_cyanophycin"
        else:
            uptakeRxn = "EX_n2"
            eatRxn = "EX_glycogen"
        
        # Updates constraints for typical objective reactions
        model.reactions.get_by_id(eatRxn).lower_bound = 0
        model.reactions.get_by_id(eatRxn).upper_bound = 1000
        model.objective = "EX_biomass"
        
        # Subsystems that should not be reversed
        subs = self.subsystemsToOmit(model)
        
        # Iterates through reactions and allows reversals
        for r in model.reactions:
            if r.id.startswith("EX") and r.id != "EX_photon" and r.id != uptakeRxn and r.id != self.export and r.id != "EX_biomass":
                lb = model.reactions.get_by_id(r.id).lower_bound
                ub = model.reactions.get_by_id(r.id).upper_bound
                r.upper_bound = 1000
                if -1*lb < r.upper_bound and ub != 1000: r.lower_bound = -1*ub
            elif r.id != "r_objective" and sol.x_dict[r.id] > 0 and r.lower_bound == 0 and r.subsystem not in subs:
                r.lower_bound = -1000
        
        # Makes sure model works
        catSol = parsimonious.optimize_minimal_flux(model)
        if catSol.f:
            for r in model.reactions:
                if catSol.x_dict[r.id] >= 0 and r.lower_bound == -1000 and self.model.reactions.get_by_id(r.id).lower_bound >= 0:
                    r.lower_bound = self.model.reactions.get_by_id(r.id).lower_bound
        return model
    
    # Subsystems that cannot be reversed (biologically and chemically insensible)
    def subsystemsToOmit(self, model):
        subs = ['Carbon Fixation', \
                'Glycolysis/Gluconeogenesis', \
                'Photosystem II', \
                'Photosystem I', \
                'Photosystem Mehler', \
                'Photosystem', \
                'Tricarboxylic Acid Cycle']
        return subs


    # Gets all the exchange reactions from the solution    
    # Get exchange reactions from metabolites
    def getExchange(self, optModel):
        if type(optModel) is not Model:
            try:
                optModel = self.jsonToModel(optModel)
            except TypeError:
                print("Infeasible Model, no exchange reactions. Aborting...")
        if not hasattr(optModel, 'solution'):
            optModel.optimize(solver='cglpk')
        if optModel.solution.status != 'infeasible': return {rxn[3:]:value for (rxn, value) in optModel.solution.x_dict.items() if re.match('EX_',rxn)}
        else: return optModel.solution.x_dict

    # Loads object from JSON string
    def jsonUndoer(self, object):
        object = json.loads(object)
        if type(object) is unicode:
            object = str(object)
        return object
    
    # Converts basic object to JSON
    def jsonDoer(self, pyObject):
        return json.dumps(pyObject)
     
    # Converts COBRA model to JSON string   
    def modelToJSON(self, model):
        return cobra.io.to_json(model)
    
    # Converts objective reaction to fluxes
    def objRxnToFluxes(self, model, weight=""):
        if not hasattr(model, 'solution'):
             model.optimize(solver='cglpk')
        rxnID = 'r_objective'
        sol = model.solution.x_dict['r_objective']
        try:
            rxn = model.reactions.get_by_id(rxnID)
        except KeyError:
            print('No scalarized objective reaction found.')
            return ''
        if not self.weights:
            for rxn in self.eqn:
                model.solution.x_dict[rxn] = sol*self.eqn[rxn] + model.solution.x_dict[rxn]
        else:
            for rxn in weight:
                model.solution.x_dict[rxn] = sol*weight[rxn] + model.solution.x_dict[rxn]
        return model

# Creates an objective equation with the appropriate weights in the model
def setObjEqn(weights, model):
    if hasObj(model):
        model.reactions.get_by_id('r_objective').delete()
        model.repair()
    
    model_one_obj = model.copy()
    rxn = Reaction('r_objective')
    rxn.name = 'Multi objective scalarized reaction.'
    rxn.subsystem = 'Objective'
    rxn.lower_bound = 0.
    rxn.upper_bound = 1000.
    rxn.objective_coefficient = 1.
    for rxnName in weights.keys():
        reaction = model_one_obj.reactions.get_by_id(rxnName)
        weight = weights[rxnName]
        for met in reaction.metabolites:
            coef = reaction.get_coefficient(met.id)
            rxn.add_metabolites({met: coef*weight})
    model_one_obj.add_reaction(rxn)
    model_one_obj.change_objective(rxn.id)
    return model_one_obj
      
# Determines whether a model contains a scalar objective function      
def hasObj(model):
    if 'r_objective' in model.reactions._dict:
        return True
    return False
    
    # Adapted from COBRA in-built functionality, but does not require JSON to be saved to disk

# Converts JSON serialized COBRA model buffer string to a COBRA model
def jsonToModel(jsonModel):
    model = Model()
    obj = json.loads(jsonModel)
    if not 'reactions' in obj:
        raise Exception('JSON object has no reactions attribute. Cannot load.')
    # Add Metabolites
    new_metabolites = []
    for metabolite in obj['metabolites']:
        new_metabolite = Metabolite()
        for k, v in iteritems(metabolite):
            setattr(new_metabolite, k, v)
        new_metabolites.append(new_metabolite)
    model.add_metabolites(new_metabolites)
    
    # Add Reactions
    new_reactions = []
    for reaction in obj['reactions']:
        new_reaction = Reaction()
        for k, v in iteritems(reaction):
            if k == 'reversibility' or k == "reaction":
                continue
            elif k == 'metabolites':
                new_reaction.add_metabolites(
                    {model.metabolites.get_by_id(met): coeff
                     for met, coeff in iteritems(v)})
            else:
                setattr(new_reaction, k, v)
        new_reactions.append(new_reaction)
    model.add_reactions(new_reactions)
    for k, v in iteritems(obj):
        if k in ['id', 'description', 'notes']:
            setattr(model, k, v)
    return model
